package za.ac.iie.quizmate

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Flashcard : AppCompatActivity() {

    private val questions = arrayOf(
        "Cape Town was the first capital city of Zimbabwe",
        "Nelson Mandela was South Africa's first black president",
        "Apartheid ended in 1960s",
        "The discovery of gold in Johannesburg led to rapid economic growth",
        "The battle of Isandlwana was a major Zulu victory against the British"
    )

    private val answers = arrayOf(false, true, false, true, true)
    private var score = 0
    private var currentIndex = 0
    private val userAnswers = mutableListOf<Boolean>()


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_flashcard)

        val txtQuestion = findViewById<TextView>(R.id.txtQuestion)
        val btnTrue = findViewById<Button>(R.id.btnTrue)
        val btnFalse = findViewById<Button>(R.id.btnFalse)
        val btnMove = findViewById<Button>(R.id.btnMove)


        fun loadQuestion() {
            if (currentIndex < questions.size) {
                txtQuestion.text = questions[currentIndex]
            } else {
                val intent = Intent(this, Score::class.java)
                intent.putExtra("score", score)
                intent.putExtra("questions", questions)
                intent.putExtra("answers", answers)
                intent.putExtra("userAnswers", userAnswers.toBooleanArray())
                startActivity(intent)
                finish()

            }
        }

        btnTrue.setOnClickListener {
            checkAnswer(true)
            loadQuestion()
        }
        btnFalse.setOnClickListener {
            checkAnswer(false)
            loadQuestion()
        }
        loadQuestion()
    }
    private fun checkAnswer(userAnswer: Boolean) {
        val correct = answers[currentIndex]
        userAnswers.add(userAnswer)

        if (userAnswer == correct) {
            Toast.makeText(this, "correct", Toast.LENGTH_SHORT).show()
            score++
        } else {
            Toast.makeText(this, "incorrect", Toast.LENGTH_SHORT).show()
        }
        currentIndex++
        if (currentIndex < questions.size) {
            val btnMove = findViewById<TextView>(R.id.txtQuestion)
            btnMove.setOnClickListener {
                btnMove.text = questions[currentIndex]

                val intent = Intent(this, Score::class.java)
                intent.putExtra("score", 0)
                intent.getStringArrayExtra("questions") ?: arrayOf()
                startActivity(intent)
                finish()

            }
        }


        {
        }





        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}